"""
Lists are a collection of data
"""


my_list = [80, 96, 72, 100, 8]
print(my_list)
my_list.append(1000)
print(my_list)
my_list.insert(2, 1000)
print(my_list)
my_list.remove(8)
print(my_list)
my_list.pop(0)
print(my_list)
my_list.sort()
print(my_list)









